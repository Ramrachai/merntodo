const express = require('express');
const mongoose = require('mongoose');
const bodyparser = require("body-parser")
const todoRoutes = require("./routes/todoRoutes")

const app = express();
const cors = require('cors');
require('dotenv').config();


// Mongo DB Connections
mongoose
    .connect(process.env.MONGO_DB_URL, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    })
    .then((response) => {
        console.log('MongoDB Connection Succeeded.');
    })
    .catch((error) => {
        console.log('Error in DB connection: ' + error);
    });

// Middleware Connections
app.use(cors());
app.use(express.json());
app.use(bodyparser.json())
app.use("/todos", todoRoutes)
// Routes
app.get('/', (req, res) => {
    console.log('home route is working');
    return res.status(200).json({
        message: 'Home route is working',
    });
});



// Connection
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`App running on http://localhost:${PORT}`);
});
